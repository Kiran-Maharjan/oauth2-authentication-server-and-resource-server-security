package com.codeaches.oauth2.authorization.server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Oauth2AuthorizationServerApplicationTests {

  @Test
  void contextLoads() {
  }
}
