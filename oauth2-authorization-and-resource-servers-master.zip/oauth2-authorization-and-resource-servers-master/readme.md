[![License MIT][MIT badge]][MIT]
[![CircleCI Build][CircleCI badge]][CircleCI]
[![][Paypal Donate Img]][Paypal Donate Link]

## Relevant documents

- The tutorial related to this project can be found on [Codeaches Website]

[MIT badge]: https://img.shields.io/:license-MIT%202.0-blue.svg
[MIT]: https://opensource.org/licenses/mit-license.php

[Paypal Donate Img]: https://www.paypalobjects.com/en_US/i/btn/btn_donate_SM.gif
[Paypal Donate Link]: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=FLER29DWAYJ58&currency_code=USD&source=url

[Codeaches Website]: https://codeaches.com

[CircleCI badge]: https://circleci.com/gh/codeaches/oauth2-authorization-and-resource-servers.svg?style=shield&circle-token=:circle-token
[CircleCI]: https://circleci.com/gh/codeaches/oauth2-authorization-and-resource-servers
